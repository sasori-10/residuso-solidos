<template>
    <img src="/img/logo.png" alt="Application Logo">
</template>
